//���ڻ��ӵ�������֤�Ķ�����VC Demo  
//���ߣ���Ϊ��  
//Email:kim@chinaidcard.com
//�绰��0755-26955558

// MyStaticDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MyStatic.h"
#include "MyStaticDlg.h"


struct defMsg{
  unsigned short name[15];
  unsigned short sex[1];
  unsigned short nation[2];
  unsigned short bY[4],bM[2],bD[2];
  unsigned short address[35];
  unsigned short id[18];
  unsigned short depart[15];
  unsigned short tsY[4],tsM[2],tsD[2];
  unsigned short tpY[4],tpM[2],tpD[2];
};

#define MSG ((struct defMsg *)&Buffer[0])

typedef int(PASCAL *lpCVR_InitComm)(int port);
typedef int(PASCAL *lpCVR_CloseComm)();
typedef int(PASCAL *lpCVR_Authenticate)();
typedef int(PASCAL *lpCVR_Read_Content)(int active);

lpCVR_InitComm CVR_InitComm;
lpCVR_CloseComm CVR_CloseComm;
lpCVR_Authenticate CVR_Authenticate;
lpCVR_Read_Content CVR_Read_Content;

HINSTANCE dllHandle;

TCHAR	szExePath[MAX_PATH];
TCHAR	*m_lpMove;



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyStaticDlg dialog

CMyStaticDlg::CMyStaticDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMyStaticDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMyStaticDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDI_ICON1); //
}

void CMyStaticDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_NAME, m_name);
    DDX_Control(pDX, IDC_SEX, m_sex);
	DDX_Control(pDX, IDC_NATION, m_nation);
	DDX_Control(pDX, IDC_BIRTH, m_birth);
	DDX_Control(pDX, IDC_IDCODE, m_idcode);
	DDX_Control(pDX, IDC_ADDR, m_addr);
	DDX_Control(pDX, IDC_DEPART, m_depart);
	DDX_Control(pDX, IDC_VALID, m_valid);

	//m_button1.SubclassDlgItem(IDC_BUTTON1, this);

	//{{AFX_DATA_MAP(CMyStaticDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMyStaticDlg, CDialog)
	//{{AFX_MSG_MAP(CMyStaticDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()		
	ON_COMMAND(IDC_BUTTON1, OnLoadddbpic)
	ON_BN_CLICKED(IDC_CLOSE, OnClose)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyStaticDlg message handlers

BOOL CMyStaticDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	SetWindowText("���ڻ��ӵ�������֤�Ķ�����Demo  ���ߣ� ��Ϊ��");   
	
    
	GetModuleFileName(AfxGetApp()->m_hInstance, szExePath, sizeof(szExePath));
    //GetShortPathName(szExePath, szExePath, MAX_PATH);
	for (m_lpMove = szExePath + lstrlen(szExePath); *(m_lpMove - 1) != '\\'; m_lpMove--);
	lstrcpy (m_lpMove, "");   
	
	//SetWindowText(szExePath); 	
    
	CString szDLLPath;
    szDLLPath.Format(_T("%s%s"), szExePath, "termb.dll");

	 dllHandle=LoadLibrary(szDLLPath);
     if (dllHandle!=NULL){
			CVR_InitComm=(lpCVR_InitComm)GetProcAddress(dllHandle,"CVR_InitComm");			
			CVR_CloseComm=(lpCVR_CloseComm)GetProcAddress(dllHandle,"CVR_CloseComm");
			CVR_Authenticate=(lpCVR_Authenticate)GetProcAddress(dllHandle,"CVR_Authenticate");
			CVR_Read_Content=(lpCVR_Read_Content)GetProcAddress(dllHandle,"CVR_Read_Content");
     
	 }
	
	// TODO: Add extra initialization here	

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.
void CMyStaticDlg::settext()
{
  m_name.SetWindowText("���ߣ� ��Ϊ�� ���ڻ��ӵ���");
}

/*void CMyStaticDlg::ProcessMessages() 
{   
	CWinApp* pApp=AfxGetApp();   
	MSG msg;   
	while ( PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE ))   
		pApp->PumpMessage();   
}   
*/

void CMyStaticDlg::OnOK()  
{
	// TODO: Add extra validation here   
	
	/*CStatic *pLabel;     
	pLabel=new CStatic; 
	pLabel->Create("hello world",
	WS_CHILD|WS_VISIBLE|SS_CENTER,
	CRect(50,80,150,150),
	this);	*/	
	//settext();
	int iRetUSB=0,iRetCOM=0;
    int iPort=0;
	for (iPort=1001; iPort<=1016; iPort++)
	{
		iRetUSB=CVR_InitComm(iPort);
		if (iRetUSB==1)
		{
		   break;
		}
	}
	if(iRetUSB != 1)
	{
	
		for (iPort=1; iPort<=16; iPort++)
		{
			iRetCOM=CVR_InitComm(iPort);
			if (iRetCOM==1)
			{
			   break;
			}
		}

	}
	
	if  ((iRetCOM==1)||(iRetUSB==1))
    {

		if (1==CVR_Authenticate())
		{
			if (1==CVR_Read_Content(1) )
			{
					OnLoadddbpic();
			}
			else
			{
					MessageBox("����ʧ�ܣ�");
			}
		}
		
	}
	else
    {
		 MessageBox("���ڴ�ʧ�ܣ�");
	}    

	
    CVR_CloseComm(); 
	//CDialog::OnOK();	
}

void CMyStaticDlg::OnLoadddbpic() 
{     
	//��ʾ����
	HANDLE handle;
	DWORD Num;
	TCHAR szWZPath[MAX_PATH];
	wsprintf (szWZPath, "%s%s", szExePath, "wz.txt");

	handle= ::CreateFile(szWZPath,GENERIC_READ|GENERIC_WRITE,0,NULL,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
	if(INVALID_HANDLE_VALUE!= handle )
	{
	
		unsigned short Buffer[128];
		memset(Buffer,0,128 );	
		::SetFilePointer(handle,0,0,FILE_BEGIN);
		::ReadFile(handle,Buffer,sizeof(Buffer),&Num,NULL);	
		::CloseHandle(handle); 
	
		char WZBuffer[128];
	    //WZBuffer = new char[256];//char[sizeof(WCHAR)];
		memset(WZBuffer,'\0',128);
		//::WideCharToMultiByte(CP_ACP,NULL,Buffer,127,WZBuffer,258,NULL,NULL);
		::WideCharToMultiByte(CP_ACP,NULL,MSG->name,15,WZBuffer,128,NULL,NULL);
		m_name.SetWindowText(WZBuffer);

        
        memset(WZBuffer,'\0',128);
		::WideCharToMultiByte(CP_ACP,NULL,MSG->sex,1,WZBuffer,128,NULL,NULL);
		if ( memcmp(WZBuffer,"1",1)==0 )
				m_sex.SetWindowText("��");
		else
		        m_sex.SetWindowText("Ů"); 	

		char strNation[100];    
		memset(WZBuffer,'\0',128);
        memset(strNation,'\0',100);
		::WideCharToMultiByte(CP_ACP,NULL,MSG->nation,2,WZBuffer,128,NULL,NULL);
        getNation( atoi(WZBuffer),strNation); 	
		m_nation.SetWindowText(strNation);

		char strTmp[30];  	
		char strTmp2[30];  
		memset(WZBuffer,'\0',128);
		memset(strTmp,'\0',30);
		memset(strTmp2,'\0',30);
		::WideCharToMultiByte(CP_ACP,NULL,MSG->bY,8,WZBuffer,128,NULL,NULL);
        memcpy(strTmp2,&WZBuffer[0],4); 
        strTmp2[4]='\0';
        strcat(strTmp,strTmp2); 		
		strcat(strTmp,"��");      
		memcpy(strTmp2,&WZBuffer[4],2); 
        strTmp2[2]='\0';
        strcat(strTmp,strTmp2);     
		strcat(strTmp,"��"); 
        memcpy(strTmp2,&WZBuffer[6],2); 
        strTmp2[2]='\0';
        strcat(strTmp,strTmp2);     
		strcat(strTmp,"��"); 
		m_birth.SetWindowText(strTmp);

		memset(WZBuffer,'\0',128);
		::WideCharToMultiByte(CP_ACP,NULL,MSG->id,18,WZBuffer,128,NULL,NULL);
        m_idcode.SetWindowText(WZBuffer);

		memset(WZBuffer,'\0',128);
		::WideCharToMultiByte(CP_ACP,NULL,MSG->address,35,WZBuffer,128,NULL,NULL);
        m_addr.SetWindowText(WZBuffer);

		memset(WZBuffer,'\0',128);
		::WideCharToMultiByte(CP_ACP,NULL,MSG->depart,15,WZBuffer,128,NULL,NULL);
        m_depart.SetWindowText(WZBuffer);

		 
		memset(WZBuffer,'\0',128);
		memset(strTmp,'\0',30);
		memset(strTmp2,'\0',30);

		::WideCharToMultiByte(CP_ACP,NULL,MSG->tsY,16,WZBuffer,128,NULL,NULL);
        memcpy(strTmp2,&WZBuffer[0],4); 
        strTmp2[4]='\0';
        strcat(strTmp,strTmp2); 		
		strcat(strTmp,"��");      
		memcpy(strTmp2,&WZBuffer[4],2); 
        strTmp2[2]='\0';
        strcat(strTmp,strTmp2);     
		strcat(strTmp,"��"); 
        memcpy(strTmp2,&WZBuffer[6],2); 
        strTmp2[2]='\0';
        strcat(strTmp,strTmp2);     
		strcat(strTmp,"��-"); 

        memcpy(strTmp2,&WZBuffer[8],4); 
        strTmp2[4]='\0';
        strcat(strTmp,strTmp2); 		
		strcat(strTmp,"��");      
		memcpy(strTmp2,&WZBuffer[12],2); 
        strTmp2[2]='\0';
        strcat(strTmp,strTmp2);     
		strcat(strTmp,"��"); 
        memcpy(strTmp2,&WZBuffer[14],2); 
        strTmp2[2]='\0';
        strcat(strTmp,strTmp2);     
		strcat(strTmp,"��"); 

		m_valid.SetWindowText(strTmp);


		//MessageBox(WZBuffer);
		/*
		int WideCharToMultiByte(
		UINT CodePage, // code page
		DWORD dwFlags, // performance and mapping flags
		LPCWSTR lpWideCharStr, // wide-character string
		int cchWideChar, // number of chars in string   -1:assume NUL-terminated
		LPSTR lpMultiByteStr, // buffer for new string
		int cbMultiByte, // size of buffer
		LPCSTR lpDefaultChar, // default for unmappable chars
		LPBOOL lpUsedDefaultChar // set when default char used
        ); //�����ַ�ת���ɶ��խ�ַ�
		*/
	}

	/*CFile file;
	char Buffer[256];
	TCHAR szWZPath2[MAX_PATH];
	wsprintf(szWZPath2, "%s%s", szExePath, "wz.txt");
	try
	{     		
		file.Open(szWZPath2, CFile::modeRead|CFile::typeBinary);
	    //file.Seek(sizeof(Buffer),CFile::begin);
		
		
		file.Read(Buffer,sizeof(Buffer));
		MessageBox(Buffer);
		file.Close();
	}
	catch(CFileException *e)
	{
		CString str;
		str.Format("��ȡ����ʧ�ܵ�ԭ����:%d",e->m_cause);
		MessageBox("str");
		file.Abort();
		e->Delete();
	}
	*/

	////////////////////////////////////////////��ʾ��Ƭ
    //����ͼƬ

    if( m_bmp.m_hObject != NULL )//�ж�
        m_bmp.DeleteObject();

    CString szXPPath;
    szXPPath.Format(_T("%s%s"), szExePath, "zp.bmp");	
	HBITMAP hbmp = (HBITMAP)::LoadImage(AfxGetInstanceHandle(), 
        szXPPath, IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION|LR_LOADFROMFILE);

    //if( hbmp == NULL ) 
        //return FALSE;

    //�öϳ�������ȡ�ü��ص�BMP����Ϣ

    m_bmp.Attach(hbmp);

	//BITMAP bmpInfo;
	//m_bmp.GetBitmap(&bmpInfo);

    DIBSECTION ds;

    BITMAPINFOHEADER &bminfo = ds.dsBmih; 

    m_bmp.GetObject( sizeof(ds), &ds );

    int cx=bminfo.biWidth;  //�õ�ͼ�����

    int cy=bminfo.biHeight; //�õ�ͼ��߶�

    //�õ���ͼ��Ŀ��Ⱥ͸߶Ⱥ�,���ǾͿ��Զ�ͼ���С������Ӧ,�������ؼ��Ĵ�С,����������ʾһ��ͼƬ

    CRect rect;

    GetDlgItem(IDC_STATIC1)->GetWindowRect(&rect);

    ScreenToClient(&rect);

    GetDlgItem(IDC_STATIC1)->MoveWindow(rect.left,rect.top,cx,cy,true);//������С	

	
    //���ͻ����豸�����ģ����ڿͻ����������
	CClientDC dc(GetDlgItem(IDC_STATIC1));

    CRect rcclient;
    GetDlgItem(IDC_STATIC1)->GetClientRect(&rcclient);   
	
    CDC dcMemory;
    dcMemory.CreateCompatibleDC(&dc);

    // Select the bitmap into the in-memory DC
    CBitmap* pOldBitmap = dcMemory.SelectObject(&m_bmp);
    
    dc.BitBlt(rcclient.left, rcclient.top, rcclient.Width(), rcclient.Height(), 
             &dcMemory, rcclient.left, rcclient.top,SRCCOPY);    

	dcMemory.SelectObject(pOldBitmap);
	dcMemory.DeleteDC();
}

void CMyStaticDlg::getNation(int code,char *pcNationStr){
    switch(code){
        case 01:  sprintf(pcNationStr,"��");break;  
        case 02:  sprintf(pcNationStr,"�ɹ�");break;
        case 03:  sprintf(pcNationStr,"��");break;
        case 04:  sprintf(pcNationStr,"��");break;
        case 05:  sprintf(pcNationStr,"ά���");break;
        case 06:  sprintf(pcNationStr,"��");break;
        case 07:  sprintf(pcNationStr,"��");break;
        case 8:   sprintf(pcNationStr,"׳");break;
        case 9:   sprintf(pcNationStr,"����");break;
        case 10:  sprintf(pcNationStr,"����");break;
        case 11:  sprintf(pcNationStr,"��");break;
        case 12:  sprintf(pcNationStr,"��");break;
        case 13:  sprintf(pcNationStr,"��");break;
        case 14:  sprintf(pcNationStr,"��");break;
        case 15:  sprintf(pcNationStr,"����");break;
        case 16:  sprintf(pcNationStr,"����");break;
        case 17:  sprintf(pcNationStr,"������");break;
        case 18:  sprintf(pcNationStr,"��");break;
        case 19:  sprintf(pcNationStr,"��");break;
        case 20:  sprintf(pcNationStr,"����");break;
        case 21:  sprintf(pcNationStr,"��");break;
        case 22:  sprintf(pcNationStr,"�");break;
        case 23:  sprintf(pcNationStr,"��ɽ");break;
        case 24:  sprintf(pcNationStr,"����");break;
        case 25:  sprintf(pcNationStr,"ˮ");break;
        case 26:  sprintf(pcNationStr,"����");break;
        case 27:  sprintf(pcNationStr,"����");break;
        case 28:  sprintf(pcNationStr,"����");break;
        case 29:  sprintf(pcNationStr,"�¶�����");break;
        case 30:  sprintf(pcNationStr,"��");break;
        case 31:  sprintf(pcNationStr,"���Ӷ�");break;
        case 32:  sprintf(pcNationStr,"����");break;
        case 33:  sprintf(pcNationStr,"Ǽ");break;
        case 34:  sprintf(pcNationStr,"����");break;
        case 35:  sprintf(pcNationStr,"����");break;
        case 36:  sprintf(pcNationStr,"ë��");break;
        case 37:  sprintf(pcNationStr,"����");break;
        case 38:  sprintf(pcNationStr,"����");break;
        case 39:  sprintf(pcNationStr,"����");break;
        case 40:  sprintf(pcNationStr,"����");break;
        case 41:  sprintf(pcNationStr,"������");break;
        case 42:  sprintf(pcNationStr,"ŭ");break;
        case 43:  sprintf(pcNationStr,"���α��");break;
        case 44:  sprintf(pcNationStr,"����˹");break;
        case 45:  sprintf(pcNationStr,"���¿�");break;
        case 46:  sprintf(pcNationStr,"�°�");break;
        case 47:  sprintf(pcNationStr,"����");break;
        case 48:  sprintf(pcNationStr,"ԣ��");break;
        case 49:  sprintf(pcNationStr,"��");break;
        case 50:  sprintf(pcNationStr,"������");break;
        case 51:  sprintf(pcNationStr,"����");break;
        case 52:  sprintf(pcNationStr,"���״�");break;
        case 53:  sprintf(pcNationStr,"����");break;
        case 54:  sprintf(pcNationStr,"�Ű�");break;
        case 55:  sprintf(pcNationStr,"���");break;
        case 56:  sprintf(pcNationStr,"��ŵ");break;
        case 97:  sprintf(pcNationStr,"����");break;
        case 98:  sprintf(pcNationStr,"���Ѫͳ�й�����ʿ");break;
        default : sprintf(pcNationStr,"");
      }     
      
}


void CMyStaticDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc1(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc1.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc1.DrawIcon(x, y, m_hIcon);  
	}
	else
	{
		CDialog::OnPaint();
	}

}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMyStaticDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


void CMyStaticDlg::OnClose() 
{	
	// TODO: Add your control notification handler code here
	CVR_CloseComm(); 
	PostQuitMessage(0);//���
}
