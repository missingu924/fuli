/*
**Copyright (c) 2009,����������ʥ�������޹�˾
**All rights reserved.
**termb.h
**description:this lib is used in windows environment
**current version: 1.0.0.0
**created time:2011-07-25
**Author:Ly
*/

#ifndef __TERMB_H__
#define __TERMB_H__

#ifdef TERMB_EXPORTS
	#define THID_IDCARD_CVR_API __declspec(dllexport)
#else
	#define THID_IDCARD_CVR_API __declspec(dllimport)
#endif

/*
**Err Code define:
*/
#define CVR_ERR_PICDECODE    2   //photo decode err
#define CVR_ERR_NONE		 1   //success
#define CVR_ERR_FAILED		 0   //failed
#define CVR_ERR_MOUDLENOAUTHORITY  -1  //this module is not authority.

/*
**CVR_InitComm(): create the link between PC and IDCard reader. 
**
**port:
**      (COM1~COM16) or (1001~1016)
**deviceName: device name to open
**return:
**      refer CVR_ERR_XXX
*/
THID_IDCARD_CVR_API int __stdcall CVR_InitComm (int Port);

/*
**InitComm(): create the link between PC and IDCard reader. 
**
**port:
**      (COM1~COM16) or (1001~1016)
**deviceName: device name to open
**return:
**      refer CVR_ERR_XXX
*/
THID_IDCARD_CVR_API int __stdcall InitComm (int Port);


/*
**CVR_CloseComm(): close the link between PC and IDCard reader. 
**
**return:
**     refer CVR_ERR_XXX  
*/
THID_IDCARD_CVR_API int __stdcall CVR_CloseComm(void);

/*
**CloseComm(): close the link between PC and IDCard reader. 
**
**return:
**     refer CVR_ERR_XXX  
*/
THID_IDCARD_CVR_API int __stdcall CloseComm(void);


/*
**CVR_Ant(): RF-Control
**mode: 
**   0: close, 1: open
**return:
**   refer CVR_ERR_XXX 
*/
THID_IDCARD_CVR_API int __stdcall CVR_Ant(int mode);

/*
**CVR_Authenticate(): Authenticated between IDCard reader and IDCard 
**
**return:
**      refer CVR_ERR_XXX    
*/
THID_IDCARD_CVR_API int __stdcall CVR_Authenticate (void);

/*
**Authenticate(): Authenticated between IDCard reader and IDCard 
**
**return:
**      refer CVR_ERR_XXX    
*/
THID_IDCARD_CVR_API int __stdcall Authenticate (void);

/*
**CVR_Read_Content():
**
**Active: the type of read Id card info
** 1:create words data WZ.TXT, photo data XP.WLT and photo ZP.BMP(decode)
** 2:create words data WZ.TXT, photo data XP.WLT
** 3:create new address NEWADD.TXT, create blank file if no new address
** 4:create WZ.TXT(decode), photo ZP.BMP(decode)
**return:
**     refer CVR_ERR_XXX
*/
THID_IDCARD_CVR_API int __stdcall CVR_Read_Content(int Active);


/*
**Read_Content():
**
**Active: the type of read Id card info
** 1:create words data WZ.TXT, photo data XP.WLT and photo ZP.BMP(decode)
** 2:create words data WZ.TXT, photo data XP.WLT
** 3:create new address NEWADD.TXT, create blank file if no new address
** 4:create WZ.TXT(decode), photo ZP.BMP(decode)
**return:
**     refer CVR_ERR_XXX
*/
THID_IDCARD_CVR_API int __stdcall Read_Content(int Active);

/*
**CVR_ReadBaseMsg():
**
**nMode: the type of read Id card info
** 1:store words data(UCS-2) into memory(pucCHMsg pointed) and photo data into memory(pucPHMsg pointed)
** 2:store words data(GBK) into memory(pucCHMsg pointed) and photo data into memory(pucPHMsg pointed)
** 3:store words data(UCS-2) into memory(pucCHMsg pointed),pucPHMsg pointed NULL,create file zp.bmp
** 4:store words data(GBK) into memory(pucCHMsg pointed),pucPHMsg pointed NULL,create file zp.bmp
**return:
**     refer CVR_ERR_XXX
*/
THID_IDCARD_CVR_API int __stdcall CVR_ReadBaseMsg(unsigned char *pucCHMsg, unsigned int *puiCHMsgLen, unsigned char *pucPHMsg, 
												  unsigned int *puiPHMsgLen, int nMode);

/*
**CVR_GetSAMID_p():
**strSAMID[out]: used store SAMID number
**
**return:
**     refer CVR_ERR_XXX
*/
THID_IDCARD_CVR_API int __stdcall CVR_GetSAMID(char *strSAMId);

/*
**GetManuID():get device module number
**pID[in]: used for store device module number
**return:
**    refer CVR_ERR_XXX;
*/
THID_IDCARD_CVR_API int __stdcall GetManuID(int *pID);
/*
**GetPeopleName(): get person name info
**strTmp:point to name info
**strLen:name info len
**return:
**     refer CVR_ERR_XXX
*/
THID_IDCARD_CVR_API int __stdcall GetPeopleName(char *strTmp, int *strLen);

/*
**GetPeopleSex(): get person sex info
**strTmp:point to sex info
**strLen:sex info len
**return:
**    refer CVR_ERR_XXX
*/
THID_IDCARD_CVR_API int __stdcall GetPeopleSex(char *strTmp, int *strLen);	

/*
**GetPeopleNation(): get person Nation info
**strTmp:point to Nation info
**strLen:Nation info len
**return:
**     refer CVR_ERR_XXX
*/
THID_IDCARD_CVR_API int __stdcall GetPeopleNation(char *strTmp, int *strLen);

/*
**GetPeopleNation(): get person Birthday info
**strTmp:point to Birthday info
**strLen:Birthday info len
**return:
**    refer CVR_ERR_XXX
*/
THID_IDCARD_CVR_API int __stdcall GetPeopleBirthday(char *strTmp, int *strLen);

/*
**GetPeopleNation(): get person Address info
**strTmp:point to Address info
**strLen:Address info len
**return:
**     refer CVR_ERR_XXX
*/
THID_IDCARD_CVR_API int __stdcall GetPeopleAddress(char *strTmp, int *strLen);	

/*
**GetPeopleNation(): get person IDCode info
**strTmp:point to IDCode info
**strLen:IDCode info len
**return:
**    refer CVR_ERR_XXX
*/
THID_IDCARD_CVR_API int __stdcall GetPeopleIDCode(char *strTmp, int *strLen);

/*
**GetPeopleNation(): get person Department info
**strTmp:point to Department info
**strLen:Department info len
**return:
**     refer CVR_ERR_XXX
*/
THID_IDCARD_CVR_API int __stdcall GetDepartment(char *strTmp, int *strLen);	

/*
**GetPeopleNation(): get person StartDate info
**strTmp:point to StartDate info
**strLen:StartDate info len
**return:
**    refer CVR_ERR_XXX
*/
THID_IDCARD_CVR_API int __stdcall GetStartDate(char *strTmp, int *strLen);

/*
**GetPeopleNation(): get person EndDate info
**strTmp:point to EndDate info
**strLen:EndDate info len
**return:
**     refer CVR_ERR_XXX
*/
THID_IDCARD_CVR_API int __stdcall GetEndDate(char *strTmp, int *strLen);	

/*
**CVR_VerifyInit(): person image VS idCard image init.
**
**
**return:
**     refer CVR_ERR_XXX
*/
THID_IDCARD_CVR_API int __stdcall CVR_VerifyInit(void);

/*
**CVR_VerifyUninit(): person image VS idCard image Uninit.
**
**
**return:
**    refer CVR_ERR_XXX
*/
THID_IDCARD_CVR_API int __stdcall CVR_VerifyUninit(void);

/*
**CVR_PersonImagVsIdCardImag(): person image VS idCard image.
**personImgData[in]: person Image Data(bmp format)
**idCardImgData[in]: idCard Image Data(bmp format)
**return:
**    refer CVR_ERR_XXX
*/
THID_IDCARD_CVR_API int __stdcall CVR_PersonImgVsIdCardImg(char *personImgData, 
		            int personImgDataLen, char *idCardImgData, int idCardImgDataLen, float *score);

#endif